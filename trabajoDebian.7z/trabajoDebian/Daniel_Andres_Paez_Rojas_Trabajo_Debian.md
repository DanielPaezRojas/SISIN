![Header del trabajo con mi nombre y mi apellido](imagenes/cabecera.PNG)
# INSTALACIÓN DE UNA MÁQUINA DEBIAN
Se debe realizar una instalación del Sistema Operativo Linux (Debian), explicando para cada paso las decisiones adoptadas y realizando la captura de pantalla de cada uno de ellos  
Guion de los pasos mínimos que se deben realizar

## CREACIÓN 
### 1. Búsqueda de la imagen en internet. 
    - Justificación de la página que se ha elegido para la descarga.  
Hemos escogido la web oficial de Debian para asegurarnos de descargar la iso correcta, oficial, actualizada y sin virus. 

![URL de la web donde he descargado el Debian](imagenes/Captura1.PNG)


    - Justificación de la “.iso” que se selecciona para la descarga.  
Hemos descargado la última versión de la iso de Debian para un PC de 64 bits (amd64). 

![ISO de la Debian que he descargado](imagenes/Captura1b.PNG)
### 2. Creación de la máquina 
    - Justificación de nombre, carpeta de la máquina, tipo y versión. 
Hemos llamado a la máquina ‘Debian_Práctica’. Hemos escogido la ruta predefinida y escodigo tipo Linux y la versión de Debian (64-bits). 

![Justificación del Debian](imagenes/Captura2.PNG)
### 3. Tamaño de memoria
    - Justificación del tamaño de memoria asignado. 
Ponemos el doble de memoria para estar seguros de tener suficiente memoria y que no de problema alguno 

![Justificación del tamaño de memoria de la máquina](imagenes/Captura3.PNG)

### 4. Creación del disco
Creamos un disco virtual con el tamaño recomendado para la máquina que nos dice por defecto VirtualBox. 

![Justificación del tamaño del disco virtual](imagenes/Captura4.PNG)

### 5. Selección del tipo de archivo del disco duro 
    - ¿Por qué elegimos vdi?
Escogemos vdi, la opción por defecto ya que las otras opciones no son necesarias y con esto nos vale. 

![Justificación del tipo de disco duro](imagenes/Captura5.PNG)


### 6.  Reservado  o  no  dinámicamente
    - ¿Por qué reservamos el espacio dinámicamente? 
Para que el tamaño del disco se ajuste al tamaño ocupado por nosotros. 

![Justificación de porque reservamos el espacio dinamicamente](imagenes/Captura6.PNG)


### 7. Ubicación del archivo o tamaño 
![Justificación de la ubicación y tamaño del archivo](imagenes/Captura7.PNG)

    - ¿Por qué la ubicación preseleccionada? 
    Porque es la ubicación predeterminada de VirtualBox.

    - ¿Por qué escogemos un tamaño concreto? 
    Para definir un límite de almacenamiento para el disco. 

## PARAMETRIZACIÓN
### 1. Instalación de las Guest Additions 
![Instalación de las Guest Additions ](imagenes/Capturaguest.PNG)

### 2. Selección de los parámetros del sistema 
    - Placa base 
    Justificación del orden de arranque, chipset y características extendidas
![Justificación del orden de arranque, chipset y características extendidas](imagenes/Captura11.PNG)
    No se hicieron grandes cambios a parte de escoger la unidad óptica antes que el disco duro.

    - Procesador
    Justificación del número de procesadores, límite de ejecución y características extendidas 
![Justificación del número de procesadores, límite de ejecución y características extendidas](imagenes/Captura11b.PNG)
    Solo hemos escogido un procesador y hemos realizado el resto de cambios así dado que no realizaremos tareas que requiren mucha potencia.

### 3. Red
    - Justificación de la elección de “Conectado a: “. Entre NAT, Adaptador Puente y Red interna 
![Justificación del tipo de red escogido](imagenes/Captura12.PNG)
    Escogeremos NAT ya que solo nos conectaremos nosotros a la máquina virtual.

    - Justificación de los desvíos de puertos necesarios (solo NAT) 
![Justificación del desvíos de puertos](imagenes/Captura121.PNG)
    Utilizaremos esta configuración para poder conectarnos por SSH.

    - ¿Carpeta compartida? 
![Justificación de la carpeta compartida](imagenes/Captura122.PNG)
    En caso de que necesitamos una carpeta compartida lo que tendríamos que hacer seria seleccionar una carpeta existente de nuestro equipo y el punto de montaje de esa carpeta dentro de la maquina

## INSTALACIÓN DEL SISTEMA OPERATIVO
### 1. Parametrización del arranque del sistema operativo en la máquina virtual 
![Parametrizaciópn de la máquina virtual](imagenes/CapturaI1.PNG)

### 2. Selección de la instalación “Gráfica” o no 
![Instalación](imagenes/CapturaI2.PNG)

### 3. Selección del idioma 
![Selección del idioma](imagenes/CapturaI3.PNG)

### 4. Selección de la ubicación 
![Selección de la ubicación](imagenes/CapturaI4.PNG)

### 5. Selección de la configuración de teclado 
![Selección de la configuración del teclado](imagenes/CapturaI5.PNG)

### 6. Elección del nombre de la máquina 
![Nombre de la máquina](imagenes/CapturaI6.PNG)

### 7. Elección del nombre de dominio (En blanco) 
![Dominio](imagenes/CapturaI7.PNG)

### 8. Clave de Superusuario 
![Clave de Superusuario](imagenes/CapturaI8.PNG)

### 9. Nombre completo del usuario 
![Nombre completo del usuario ](imagenes/CapturaI9.PNG)

### 10. Nombre de usuario 
![Nombre del usuario](imagenes/CapturaI10.PNG)

### 11. Clave del usuario 
![Clave del usuario](imagenes/CapturaI11.PNG)

### 12. Selección de la ubicación de zona horaria 
![Zona horaria](imagenes/CapturaI12.PNG)

### 13. Particionamiento de datos 
![Particionamiento de datos](imagenes/CapturaI13.PNG)

### 14. Selección del disco de instalación 
![Particionamiento de disco](imagenes/CapturaI14.PNG)

### 15. Selección del esquema de particionamiento 
![Esquema de particionamiento ](imagenes/CapturaI15.PNG)

### 16. Resumen de la instalación y finalización 
![Resumen](imagenes/CapturaI16.PNG)

### 17. Confirmación de los cambios 
![Confirmación de cambios](imagenes/CapturaI17.PNG)

### 18. Gestión de medios de instalación adicionales (NO) 
![Gestión de medios de instalación adicionales](imagenes/CapturaI18.PNG)

### 19. País de la réplica de Debian 
![Gestión de medios de instalación adicionales](imagenes/CapturaI19.PNG)

### 20. Elección de la réplica de Debian 
![Réplica de Debian](imagenes/CapturaI20.PNG)

### 21. Información del Proxy 
![Proxy](imagenes/CapturaI21.PNG)

### 22. Elección de los programas a instalar 
![Elección de los programas a instalar](imagenes/CapturaI22.PNG)

### 23. Instalar cargador de arranque “grup” (SI, y en /dev/sda) 
![Instalar cargador de arranque](imagenes/CapturaI23.PNG)
![Instalar cargador de arranque](imagenes/CapturaI23a.PNG)


## CONFIGURACIÓN INICIAL DEL SISTEMA OPERATIVO 
### 1. Configuración inicial de la clave de superusuario
![Configuración de root](imagenes/CapturaC1.PNG)

### 2. Configuración del acceso remoto 
![Configuración del acceso remoto](imagenes/CapturaC2.PNG)

### 3. Reenvío de puertos 
![Justificación del reenvio de puertos](imagenes/Captura121.PNG)

### 4. Actualización del sistema 
Para buscar una actualización del sistema simplemente entratemos a la Oracle VM VirtualBox Administrador --> Archivo --> Comprobar Actualizaciones  
![Actualización del sistema ](imagenes/CapturaC4.PNG)

### 5. Copia de seguridad (Instantánea/Exportación) 
Para realizar una instantánea le daremos a el menú de opciones de la máquina a la que queramos realizar la instantánea en Oracle VM VirtualBox Administrador y seleccionamos la opción de instantáneas
Una vez hecho esto le daremos a la primera opción, 'tomar' y elegiremos el nombre de la instantánea que querramos y una descripción (o no).  
Al haber realizado todo esto la máquina virtual se guardará en esa instantánea tal cual la dejamos en el momento de haber hecho la instantánea.  
![Instantanea](imagenes/CapturaC5.PNG)

Si lo que queremos es exportar la máquina simplemente en el menú de inicio de Oracle VM VirtualBox Administrador le daremos a Archivo --> Exportar servicio virtualizado.  
![Exportación](imagenes/CapturaC5b.PNG)